// ملف JavaScript الرئيسي - فريق ساتيك

// ============ تعريف المتغيرات العامة ============
let currentLang = 'ar';
let countdownInterval = null;

// ============ بيانات الترجمة ============
const translations = {
    ar: {
        // قائمة التنقل
        "home": "الرئيسية",
        "about": "من نحن",
        "projects": "المشاريع",
        "contact": "تواصل معنا",
        
        // القسم الرئيسي
        "heroTitle": "فريق ساتيك السعودي",
        "heroText": "نُطوّر مشاريع وأفكار تقنية سعودية تصنع أثرًا حقيقيًا.",
        "discover": "اكتشفنا",
        
        // قسم من نحن
        "aboutTitle": "من نحن",
        "aboutText": "ساتيك فريق سعودي شغوف بالتقنية وريادة الأعمال. نحول الأفكار إلى منتجات رقمية عملية بجودة عالية وتجربة استخدام ممتازة.",
        "values": "قيمنا: الاحترافية، الشفافية، روح الفريق.",
        "domains": "مجالاتنا: الويب، أدوات تعليمية، حلول ذكية.",
        "goal": "هدفنا: منتج عربي يفخر به المستخدم.",
        "team": "تعرف على الفريق",
        
        // قسم المشاريع
        "projectsTitle": "المشاريع",
        "project1": "Satech education",
        "project1Desc": "لوحة تحكم مدرسية ذكية، صممت لإدارة المدرسة بسهولة وفاعلية، تجمع كل المعلومات والمهام في مكان واحد.",
        "project2": "موسوعة تفاعلية",
        "project2Desc": "موسوعة تفاعلية سعودية، تجمع المعرفة المحلية بطريقة ديناميكية تسمح للمستخدمين بالتفاعل والاكتشاف.",
        "project3": "Satech OS",
        "project3Desc": "نظام تشغيل سعودي بالكامل، صُمم ليعكس رؤية المملكة في الاعتماد على حلول وطنية مستقلة وآمنة.",
        
        // قسم التواصل
        "contactTitle": "تواصل معنا",
        "tiktokTitle": "تيك توك",
        "tiktokDesc": "مشاريع الفريق ولقطات ممتعة",
        "discordTitle": "دِسكورد",
        "discordDesc": "سيرفر المجتمع—انضم وتابع كل جديد",
        "xTitle": "X",
        "xDesc": "أحدث الأخبار والتحديثات",
        "instagramTitle": "إنستجرام",
        "instagramDesc": "لحظات خلف الكواليس وصور المشاريع",
        "emailTitle": "البريد الإلكتروني",
        "emailDesc": "للتواصل الرسمي والاستفسارات",
        
        // الفوتر
        "footer": "© 2025 جميع الحقوق محفوظة - فريق ساتيك",
        
        // النوافذ المنبثقة
        "comingSoon": "قريباً",
        "emailPopupTitle": "البريد الإلكتروني",
        "copy": "نسخ",
        "close": "إغلاق",
        "countdownText": "ستُغلق هذه النافذة تلقائيًا خلال ",
        "seconds": "ثانية",
        "copied": "تم النسخ!",
        "ok": "حسناً"
    },
    en: {
        // Navigation
        "home": "Home",
        "about": "About Us",
        "projects": "Projects",
        "contact": "Contact Us",
        
        // Hero Section
        "heroTitle": "Satech Saudi Team",
        "heroText": "We develop Saudi tech projects and ideas that create real impact.",
        "discover": "Discover Us",
        
        // About Section
        "aboutTitle": "About Us",
        "aboutText": "Satech is a Saudi team passionate about technology and entrepreneurship. We transform ideas into practical digital products with high quality and excellent user experience.",
        "values": "Our values: Professionalism, Transparency, Team Spirit.",
        "domains": "Our domains: Web, Educational Tools, Smart Solutions.",
        "goal": "Our goal: An Arabic product that users can be proud of.",
        "team": "Meet the Team",
        
        // Projects Section
        "projectsTitle": "Projects",
        "project1": "Satech education",
        "project1Desc": "Smart school dashboard designed for easy and effective school management, bringing all information and tasks in one place.",
        "project2": "Interactive Encyclopedia",
        "project2Desc": "A Saudi interactive encyclopedia that gathers local knowledge in a dynamic way allowing users to interact and explore.",
        "project3": "Satech OS",
        "project3Desc": "A fully Saudi operating system, designed to reflect the Kingdom's vision of relying on independent and secure national solutions.",
        
        // Contact Section
        "contactTitle": "Contact Us",
        "tiktokTitle": "TikTok",
        "tiktokDesc": "Team projects and fun clips",
        "discordTitle": "Discord",
        "discordDesc": "Community server—join and follow all updates",
        "xTitle": "X",
        "xDesc": "Latest news and updates",
        "instagramTitle": "Instagram",
        "instagramDesc": "Behind-the-scenes moments and project photos",
        "emailTitle": "Email",
        "emailDesc": "For official communication and inquiries",
        
        // Footer
        "footer": "© 2025 All rights reserved - Satech Team",
        
        // Popups
        "comingSoon": "Coming Soon",
        "emailPopupTitle": "Email",
        "copy": "Copy",
        "close": "Close",
        "countdownText": "This window will close automatically in ",
        "seconds": "seconds",
        "copied": "Copied!",
        "ok": "OK"
    }
};

// ============ الدوال الأساسية ============

/**
 * تهيئة نظام الأكورديون
 */
function initAccordion() {
    const accordions = document.querySelectorAll('.accordion');
    
    accordions.forEach(accordion => {
        accordion.addEventListener('click', function() {
            // إغلاق جميع الأكورديونات الأخرى
            accordions.forEach(otherAcc => {
                if (otherAcc !== this && otherAcc.classList.contains('active')) {
                    otherAcc.classList.remove('active');
                    const otherPanel = otherAcc.nextElementSibling;
                    if (otherPanel && otherPanel.classList.contains('panel')) {
                        otherPanel.style.maxHeight = null;
                    }
                }
            });
            
            // تبديل الحالة الحالية
            this.classList.toggle('active');
            const panel = this.nextElementSibling;
            
            if (panel && panel.classList.contains('panel')) {
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.style.maxHeight = panel.scrollHeight + "px";
                }
            }
        });
    });
}

/**
 * التنقل السلس إلى قسم معين
 * @param {string} sectionId - معرف القسم
 */
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }
}

/**
 * تبديل لغة الموقع
 * @param {string} lang - اللغة الجديدة ('ar' أو 'en')
 */
function translatePage(lang) {
    // تحديث المتغير العام
    currentLang = lang;
    
    // تحديث لغة واتجاه المستند
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    
    // تحديث نص زر تبديل اللغة
    const langButton = document.getElementById('lang-switcher');
    if (langButton) {
        const langText = langButton.querySelector('span');
        if (langText) {
            langText.textContent = lang === 'ar' ? 'EN' : 'AR';
        }
    }
    
    // تحديث جميع العناصر التي تحتوي على data-translate
    const translatableElements = document.querySelectorAll('[data-translate]');
    
    translatableElements.forEach(element => {
        const key = element.getAttribute('data-translate');
        
        if (translations[lang] && translations[lang][key]) {
            // تحديث النصوص فقط (ليس الأيقونات)
            if (element.tagName === 'SPAN' || element.tagName === 'P' || element.tagName === 'H1' || element.tagName === 'H3') {
                element.textContent = translations[lang][key];
            }
        }
    });
    
    // تحديث النصوص في النوافذ المنبثقة إذا كانت مفتوحة
    updatePopupTexts();
}

/**
 * تحديث نصوص النوافذ المنبثقة
 */
function updatePopupTexts() {
    const popup = document.getElementById('dynamicPopup');
    if (!popup || !popup.classList.contains('active')) return;
    
    const popupTitle = document.getElementById('popupTitle');
    const countdownText = document.getElementById('countdownText');
    const countdownNumber = document.getElementById('countdownNumber');
    
    if (popupTitle && countdownText && countdownNumber) {
        // تحديث النص إذا كانت نافذة "قريباً"
        if (popupTitle.textContent === 'قريباً' || popupTitle.textContent === 'Coming Soon') {
            popupTitle.textContent = translations[currentLang].comingSoon;
        }
        
        // تحديث العداد التنازلي
        const currentSeconds = parseInt(countdownNumber.textContent);
        countdownText.innerHTML = `${translations[currentLang].countdownText}<span id="countdownNumber">${currentSeconds}</span> ${translations[currentLang].seconds}`;
    }
}

/**
 * إظهار نافذة "قريباً"
 * @param {string} platform - اسم المنصة
 * @param {string} iconClass - كلاس الأيقونة
 */
function showComingSoonPopup(platform, iconClass) {
    // إلغاء أي عداد سابق
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
    
    // الحصول على عناصر النافذة
    const popup = document.getElementById('dynamicPopup');
    const popupIcon = document.getElementById('popupIcon');
    const popupTitle = document.getElementById('popupTitle');
    const popupMessage = document.getElementById('popupMessage');
    const popupActions = document.getElementById('popupActions');
    const countdownText = document.getElementById('countdownText');
    const countdownNumber = document.getElementById('countdownNumber');
    
    if (!popup || !popupIcon || !popupTitle || !popupMessage || !popupActions || !countdownText || !countdownNumber) {
        console.error('عناصر النافذة المنبثقة غير موجودة');
        return;
    }
    
    // تعيين المحتوى
    popupIcon.className = iconClass;
    popupTitle.textContent = translations[currentLang].comingSoon;
    
    const message = currentLang === 'ar' 
        ? `حسابنا على ${platform} قيد الإنشاء حالياً وسيكون متاحاً قريباً. تابعنا على منصات التواصل الأخرى للاطلاع على آخر التحديثات.`
        : `Our ${platform} account is currently under construction and will be available soon. Follow us on other platforms to stay updated.`;
    
    popupMessage.textContent = message;
    
    // إعداد الأزرار
    popupActions.innerHTML = `
        <button class="popup-button primary" onclick="closePopup()">
            <i class="fa-solid fa-thumbs-up"></i>
            ${translations[currentLang].ok}
        </button>
    `;
    
    // إعداد عداد التنازلي
    let seconds = 2;
    countdownNumber.textContent = seconds;
    countdownText.innerHTML = `${translations[currentLang].countdownText}<span id="countdownNumber">${seconds}</span> ${translations[currentLang].seconds}`;
    
    // إظهار النافذة
    popup.classList.add('active');
    
    // بدء عداد التنازلي
    countdownInterval = setInterval(() => {
        seconds--;
        countdownNumber.textContent = seconds;
        
        if (seconds <= 0) {
            closePopup();
        }
    }, 1000);
}

/**
 * إظهار نافذة البريد الإلكتروني
 */
function showEmailPopup() {
    // إلغاء أي عداد سابق
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }
    
    // الحصول على عناصر النافذة
    const popup = document.getElementById('dynamicPopup');
    const popupIcon = document.getElementById('popupIcon');
    const popupTitle = document.getElementById('popupTitle');
    const popupMessage = document.getElementById('popupMessage');
    const popupActions = document.getElementById('popupActions');
    const countdownText = document.getElementById('countdownText');
    const countdownNumber = document.getElementById('countdownNumber');
    
    if (!popup || !popupIcon || !popupTitle || !popupMessage || !popupActions || !countdownText || !countdownNumber) {
        console.error('عناصر النافذة المنبثقة غير موجودة');
        return;
    }
    
    // تعيين المحتوى
    popupIcon.className = 'fa-solid fa-envelope-circle-check';
    popupTitle.textContent = translations[currentLang].emailPopupTitle;
    
    const email = 'contact@sattech.com';
    const message = currentLang === 'ar' 
        ? `يمكنك التواصل معنا عبر البريد الإلكتروني الرسمي للفريق:<br><strong>${email}</strong><br><br>سيتم الرد على استفساراتك خلال 24 ساعة عمل.`
        : `You can contact us through the team's official email:<br><strong>${email}</strong><br><br>We will reply to your inquiries within 24 working hours.`;
    
    popupMessage.innerHTML = message;
    
    // إعداد الأزرار
    popupActions.innerHTML = `
        <button class="popup-button primary" onclick="copyToClipboard('${email}')">
            <i class="fa-solid fa-copy"></i>
            ${translations[currentLang].copy}
        </button>
        <button class="popup-button secondary" onclick="closePopup()">
            <i class="fa-solid fa-times"></i>
            ${translations[currentLang].close}
        </button>
    `;
    
    // إعداد عداد التنازلي
    let seconds = 5;
    countdownNumber.textContent = seconds;
    countdownText.innerHTML = `${translations[currentLang].countdownText}<span id="countdownNumber">${seconds}</span> ${translations[currentLang].seconds}`;
    
    // إظهار النافذة
    popup.classList.add('active');
    
    // بدء عداد التنازلي
    countdownInterval = setInterval(() => {
        seconds--;
        countdownNumber.textContent = seconds;
        
        if (seconds <= 0) {
            closePopup();
        }
    }, 1000);
}

/**
 * إغلاق النافذة المنبثقة
 */
function closePopup() {
    const popup = document.getElementById('dynamicPopup');
    
    if (!popup) return;
    
    // إضافة تأثير الإغلاق
    popup.style.animation = 'popupDisappear 0.3s forwards';
    
    setTimeout(() => {
        popup.classList.remove('active');
        popup.style.animation = '';
        
        // إلغاء العداد
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }
    }, 300);
}

/**
 * نسخ النص إلى الحافظة
 * @param {string} text - النص المطلوب نسخه
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        // إظهار رسالة النجاح
        const popupActions = document.getElementById('popupActions');
        if (popupActions) {
            const originalHTML = popupActions.innerHTML;
            
            popupActions.innerHTML = `
                <button class="popup-button primary" style="background: #00a857;">
                    <i class="fa-solid fa-check"></i>
                    ${translations[currentLang].copied}
                </button>
            `;
            
            // العودة إلى الأزرار الأصلية بعد 1.5 ثانية
            setTimeout(() => {
                popupActions.innerHTML = originalHTML;
            }, 1500);
        }
    }).catch(err => {
        console.error('فشل في نسخ النص:', err);
    });
}

/**
 * تهيئة تعقب القسم النشط أثناء التمرير
 */
function initScrollSpy() {
    const sections = document.querySelectorAll('section[id], main[id]');
    const navLinks = document.querySelectorAll('.nav-links a');
    
    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.clientHeight;
            
            if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

// ============ تهيئة الصفحة ============

/**
 * تهيئة جميع الأحداث عند تحميل الصفحة
 */
function initPage() {
    console.log('جاري تهيئة صفحة فريق ساتيك...');
    
    // 1. تهيئة تعقب القسم النشط
    initScrollSpy();
    
    // 2. تهيئة الأكورديون
    initAccordion();
    
    // 3. تهيئة زر تبديل اللغة
    const langSwitcher = document.getElementById('lang-switcher');
    if (langSwitcher) {
        langSwitcher.addEventListener('click', () => {
            const newLang = currentLang === 'ar' ? 'en' : 'ar';
            translatePage(newLang);
        });
    }
    
    // 4. تهيئة أزرار التنقل
    const discoverBtn = document.getElementById('discoverBtn');
    if (discoverBtn) {
        discoverBtn.addEventListener('click', () => scrollToSection('projects'));
    }
    
    const teamBtn = document.getElementById('teamBtn');
    if (teamBtn) {
        teamBtn.addEventListener('click', () => {
            window.location.href = 'About.html';
        });
    }
    
    // 5. تهيئة روابط التواصل الاجتماعي
    const xLink = document.getElementById('xLink');
    if (xLink) {
        xLink.addEventListener('click', (e) => {
            e.preventDefault();
            showComingSoonPopup('X', 'fa-brands fa-x-twitter');
        });
    }
    
    const instagramLink = document.getElementById('instagramLink');
    if (instagramLink) {
        instagramLink.addEventListener('click', (e) => {
            e.preventDefault();
            showComingSoonPopup('إنستجرام', 'fa-brands fa-instagram');
        });
    }
    
    const emailLink = document.getElementById('emailLink');
    if (emailLink) {
        emailLink.addEventListener('click', (e) => {
            e.preventDefault();
            showEmailPopup();
        });
    }
    
    // 6. تهيئة إغلاق النافذة المنبثقة بالنقر خارجها
    const popup = document.getElementById('dynamicPopup');
    if (popup) {
        popup.addEventListener('click', function(e) {
            if (e.target === this) {
                closePopup();
            }
        });
    }
    
    // 7. إضافة التنقل السلس لروابط القائمة
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId && targetId.startsWith('#')) {
                e.preventDefault();
                scrollToSection(targetId.substring(1));
            }
        });
    });
    
    console.log('تم تهيئة الصفحة بنجاح!');
}

// ============ تعريض الدوال للاستخدام العام ============
window.scrollToSection = scrollToSection;
window.showComingSoonPopup = showComingSoonPopup;
window.showEmailPopup = showEmailPopup;
window.closePopup = closePopup;
window.copyToClipboard = copyToClipboard;
window.translatePage = translatePage;

// ============ بدء التشغيل عند تحميل الصفحة ============
document.addEventListener('DOMContentLoaded', initPage);

// بديل إذا فشل DOMContentLoaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPage);
} else {
    initPage();
}